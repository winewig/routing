import { Component, OnInit } from '@angular/core';
import {Observable} from 'rxjs';
import {ActivatedRoute} from '@angular/router';
import {map, switchMap, tap} from 'rxjs/operators';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss']
})
export class AdminDashboardComponent implements OnInit {
  sessionId$: Observable<string>;
  token$: Observable<string>;

  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    // Capture the session ID if available
    this.sessionId$ = this.route.queryParamMap.pipe(
      switchMap( params => params.get('session_id') || 'None')
    );

    // Capture the fragment if available
    this.token$ = this.route.fragment.pipe(
      tap( fragment => console.log('kk', fragment)),
      map( fragment => fragment || 'None')
    );
  }

}
