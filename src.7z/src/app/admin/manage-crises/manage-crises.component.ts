import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-crises',
  templateUrl: './manage-crises.component.html',
  styleUrls: ['./manage-crises.component.scss']
})
export class ManageCrisesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
