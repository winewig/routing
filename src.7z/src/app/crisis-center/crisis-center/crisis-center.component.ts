import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crisis-center',
  templateUrl: './crisis-center.component.html',
  styleUrls: ['./crisis-center.component.scss']
})
export class CrisisCenterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
