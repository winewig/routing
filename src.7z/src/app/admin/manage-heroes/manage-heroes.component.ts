import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-heroes',
  templateUrl: './manage-heroes.component.html',
  styleUrls: ['./manage-heroes.component.scss']
})
export class ManageHeroesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
